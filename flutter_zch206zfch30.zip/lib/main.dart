import 'package:flutter/material.dart';
 
void main() {
  runApp(StudyNotesApp());
}
 
class StudyNotesApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App de Anotações de Estudos',
      theme: ThemeData(
        primarySwatch: createMaterialColor(Color(0xff2a0308)),
      ),
      home: NoteListScreen(),
    );
  }
 
  MaterialColor createMaterialColor(Color color) {
    return MaterialColor(color.value, <int, Color>{
      50: color.withOpacity(0.1),
      100: color.withOpacity(0.2),
      200: color.withOpacity(0.3),
      300: color.withOpacity(0.4),
      400: color.withOpacity(0.5),
      500: color, // Primary color
      600: color.withOpacity(0.6),
      700: color.withOpacity(0.7),
      800: color.withOpacity(0.8),
      900: color.withOpacity(0.9),
    });
  }
}
 
class NoteListScreen extends StatefulWidget {
  @override
  _NoteListScreenState createState() => _NoteListScreenState();
}
 
class _NoteListScreenState extends State<NoteListScreen> {
  List<Map<String, String>> notes = [];
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Anotações de Estudos'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => NoteFormScreen(
                    onSave: (newNote) {
                      setState(() {
                        notes.add(newNote);
                      });
                    },
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Container(
        color: Color(0xFFF8EBBE),
        child: ListView.builder(
          itemCount: notes.length,
          itemBuilder: (context, index) {
            final note = notes[index];
            return NoteCard(
              note: note,
              onEdit: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => NoteFormScreen(
                      note: note,
                      onSave: (updatedNote) {
                        setState(() {
                          notes[index] = updatedNote;
                        });
                      },
                      onDelete: () {
                        setState(() {
                          notes.removeAt(index);
                        });
                        Navigator.pop(context);
                      },
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
 
 
class NoteCard extends StatelessWidget {
  final Map<String, String> note;
  final VoidCallback onEdit;
  NoteCard({required this.note, required this.onEdit});
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10.0),
      elevation: 5,
      child: ListTile(
        title: Text(note['titulo']!),
        subtitle: Text(note['conteúdo']!),
        trailing: IconButton(
          icon: Icon(Icons.edit),
          onPressed: onEdit,
        ),
      ),
    );
  }
}
 
class NoteFormScreen extends StatefulWidget {
  final Map<String, String>? note;
  final Function(Map<String, String>) onSave;
  final VoidCallback? onDelete;
  NoteFormScreen({this.note, required this.onSave, this.onDelete});
  @override
  _NoteFormScreenState createState() => _NoteFormScreenState();
}
 
class _NoteFormScreenState extends State<NoteFormScreen> {
  final _formKey = GlobalKey<FormState>();
  String _titulo = '';
  String _conteudo = '';
  @override
  void initState() {
    super.initState();
    if (widget.note != null) {
      _titulo = widget.note!['titulo']!;
      _conteudo = widget.note!['conteúdo']!;
    }
  }
 
  @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text(widget.note == null ? 'Adicionar Nota' : 'Editar Nota'),
    ),
    backgroundColor: Color(0xfff8ebbe),
    body: Padding(
      padding: EdgeInsets.all(16.0),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            TextFormField(
              initialValue: _titulo,
              decoration: InputDecoration(labelText: 'Título'),
              onSaved: (value) {
                _titulo = value ?? '';
              },
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor, insira um título';
                }
                return null;
              },
            ),
            TextFormField(
              initialValue: _conteudo,
              decoration: InputDecoration(labelText: 'Conteúdo'),
              onSaved: (value) {
                _conteudo = value ?? '';
              },
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor, insira o conteúdo';
                }
                return null;
              },
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      _formKey.currentState!.save();
                      widget.onSave({'titulo': _titulo, 'conteúdo': _conteudo});
                      Navigator.pop(context);
                    }
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Color(0xffe2ac3f)),
                  child: Text('Salvar'),
                ),
                if (widget.note != null)
                  ElevatedButton(
                    onPressed: widget.onDelete,
                    style: ElevatedButton.styleFrom(backgroundColor: Color(0xffe2ac3f)),
                    child: Text('Excluir'),
                  ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
 
}